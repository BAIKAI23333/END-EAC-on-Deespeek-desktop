# @dsh-eac/desktop-pack

Official DSH Desktop 0.1.7-rc.2 aggregate bundle. Install this one `.tgz` through the official plugin manager or `dsh plugin add`; the package carries all 14 member packages and the only aggregate patch layer.
